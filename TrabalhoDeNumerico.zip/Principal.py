from MetodoDaBisseccao import Bisseccao
from MetodoDeNewton import Newton

def main (  ) :

    a = float( input ( "Digite o valor do intervalo de a :" ) )
    b = float( input ( "Digite o valor do intervalo de b :" ) )
    epsilon = float( input ( "Digite o valor do epsion1 de máquina :" ) )

    bisseccao = Bisseccao.bisseccao ( a, b, epsilon )
    bisseccao.calculoIteracao()
    print("Valor da raiz : {} ".format ( bisseccao.raiz ) )

    epsilon1 = float(input("Digite o valor do epsion1 de máquina :"))
    epsilon2 = float(input("Digite o valor do epsion2 de máquina :"))

    newton = Newton.Newton( 4, epsilon1, epsilon2 )
    newton.calculoInteracao()
    print("Valor da raiz : {} ".format ( newton.raiz ) )

if __name__ == '__main__':
    main()